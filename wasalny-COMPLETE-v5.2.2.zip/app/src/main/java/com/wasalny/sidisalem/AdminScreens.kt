package com.wasalny.sidisalem

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** الكود السري الثابت لدخول المشرف */
private const val ADMIN_SECRET_CODE = "5122017@Aa"

@Composable
fun AdminLoginScreen(onBack: () -> Unit, onSuccess: () -> Unit) {
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val repository = remember { FirebaseRidesRepository() }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔐 دخول المشرف", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("أدخل الكود السري للوصول للوحة التحكم", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.size(20.dp))
        OutlinedTextField(
            value = code,
            onValueChange = { code = it; error = null },
            label = { Text("الكود السري") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )
        if (error != null) {
            Spacer(Modifier.size(8.dp))
            Text(error!!, color = Color(0xFFB3261E), fontSize = 13.sp)
        }
        Spacer(Modifier.size(16.dp))
        Button(
            enabled = !busy && code.isNotBlank(),
            onClick = {
                busy = true
                error = null
                scope.launch {
                    try {
                        if (code.trim() != ADMIN_SECRET_CODE) {
                            error = "الكود غير صحيح"
                            return@launch
                        }
                        // الإبقاء على الجلسة الحالية إن وُجدت، وإلا تسجيل مجهول
                        val auth = com.google.firebase.auth.FirebaseAuth.getInstance()
                        val uid = auth.currentUser?.uid ?: repository.signInAnonymously()
                        android.util.Log.i("WasalnyAdmin", "Admin session UID=$uid — أضفه في Firestore/admins")
                        onSuccess()
                    } catch (e: Exception) {
                        error = e.localizedMessage ?: "تعذر الدخول"
                    } finally {
                        busy = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D7C3E))
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
            else Text("دخول", fontWeight = FontWeight.Bold)
        }
        Text(
            "بعد الدخول: أضف UID حسابك في مجموعة admins داخل Firestore",
            color = Color.Gray,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 8.dp)
        )
        TextButton(onClick = onBack, enabled = !busy) { Text("رجوع") }
    }
}

@Composable
fun AdminPanel(onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("السائقون", "الاشتراكات", "الرحلات", "التقييمات")

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("لوحة المشرف", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            TextButton(onClick = onLogout) { Text("خروج") }
        }
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
            tabs.forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title, fontSize = 13.sp) })
            }
        }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> AdminDriversTab()
            1 -> AdminSubscriptionsTab()
            2 -> AdminRidesTab()
            3 -> AdminRatingsTab()
        }
    }
}

@Composable
private fun AdminDriversTab() {
    val repository = remember { FirebaseRidesRepository() }
    val scope = rememberCoroutineScope()
    var drivers by remember { mutableStateOf<List<DriverCandidate>>(emptyList()) }
    var allDrivers by remember { mutableStateOf<List<DriverApplication>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var selectedDriver by remember { mutableStateOf<DriverCandidate?>(null) }
    var savingUid by remember { mutableStateOf<String?>(null) }
    var driverDetails by remember { mutableStateOf<DriverApplication?>(null) }

    DisposableEffect(Unit) {
        val registration = repository.listenPendingDrivers(
            { drivers = it },
            { error = it.localizedMessage ?: "تعذر تحميل طلبات السائقين" }
        )
        onDispose { registration.remove() }
    }

    LaunchedEffect(Unit) {
        runCatching { allDrivers = repository.listAllDrivers() }
            .onFailure { error = it.localizedMessage }
    }

    Column(Modifier.fillMaxSize()) {
        Text("طلبات بانتظار الاعتماد: ${drivers.size}", color = Color.Gray, fontSize = 13.sp)
        if (error != null) Text(error!!, color = Color(0xFFB3261E))
        Spacer(Modifier.size(8.dp))
        if (drivers.isEmpty()) {
            Text("لا توجد طلبات سائقين جديدة.", color = Color.Gray)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f, fill = false)) {
                items(drivers, key = { it.uid }) { driver ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(driver.displayName, fontWeight = FontWeight.Bold)
                            Text("UID: ${driver.uid.take(10)}…", color = Color.Gray, fontSize = 11.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    enabled = savingUid == null,
                                    onClick = {
                                        selectedDriver = driver
                                        scope.launch { driverDetails = repository.getDriverApplication(driver.uid) }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D7C3E))
                                ) { Text("مراجعة") }
                                OutlinedButton(
                                    enabled = savingUid == null,
                                    onClick = {
                                        savingUid = driver.uid
                                        scope.launch {
                                            try {
                                                repository.setDriverApproval(driver.uid, false)
                                                repository.requestDriverMoreData(driver.uid, "يرجى استكمال البيانات والصور")
                                            } catch (e: Exception) {
                                                error = e.localizedMessage
                                            } finally { savingUid = null }
                                        }
                                    }
                                ) { Text("طلب استكمال") }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("كل السائقين المعتمدين", fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(allDrivers.filter { it.approved }, key = { it.uid }) { d ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(d.name, fontWeight = FontWeight.Medium)
                        Text("${d.phone} • ${d.vehicleType}", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        }
    }

    selectedDriver?.let { driver ->
        AlertDialog(
            onDismissRequest = { if (savingUid == null) selectedDriver = null },
            title = { Text("اعتماد السائق") },
            text = {
                Column {
                    Text("هل تريد اعتماد ${driver.displayName}؟")
                    Spacer(Modifier.size(8.dp))
                    Text("الاسم: ${driverDetails?.name ?: driver.displayName}", color = Color.Gray)
                    Text("الهاتف: ${driverDetails?.phone ?: "—"}", color = Color.Gray)
                    Text("الرخصة: ${driverDetails?.licenseType ?: "—"}", color = Color.Gray)
                    Text("المركبة: ${driverDetails?.vehicleType ?: "—"}", color = Color.Gray)
                    if (!driverDetails?.idCardImageUrl.isNullOrBlank()) {
                        Text("بطاقة: مرفوعة ✓", color = Color(0xFF0D7C3E), fontSize = 12.sp)
                    }
                    if (!driverDetails?.vehicleImageUrl.isNullOrBlank()) {
                        Text("مركبة: مرفوعة ✓", color = Color(0xFF0D7C3E), fontSize = 12.sp)
                    }
                    if (!driverDetails?.profileImageUrl.isNullOrBlank()) {
                        Text("صورة شخصية: مرفوعة ✓", color = Color(0xFF0D7C3E), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = savingUid == null,
                    onClick = {
                        savingUid = driver.uid
                        scope.launch {
                            try {
                                repository.setDriverApproval(driver.uid, true)
                                selectedDriver = null
                                driverDetails = null
                            } catch (e: Exception) {
                                error = e.localizedMessage
                            } finally { savingUid = null }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D7C3E))
                ) { Text("اعتماد") }
            },
            dismissButton = {
                TextButton(onClick = { selectedDriver = null }, enabled = savingUid == null) { Text("إلغاء") }
            }
        )
    }
}

@Composable
private fun AdminSubscriptionsTab() {
    val repository = remember { FirebaseRidesRepository() }
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<List<SubscriptionRequest>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var busyId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        runCatching { pending = repository.listPendingSubscriptions() }
            .onFailure { error = it.localizedMessage }
    }

    Column(Modifier.fillMaxSize()) {
        Text("طلبات تجديد الاشتراك (فودافون كاش)", fontWeight = FontWeight.Bold)
        if (error != null) Text(error!!, color = Color(0xFFB3261E))
        Spacer(Modifier.height(8.dp))
        if (pending.isEmpty()) {
            Text("لا توجد طلبات اشتراك حالياً.", color = Color.Gray)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(pending, key = { it.id }) { req ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(req.driverName, fontWeight = FontWeight.Bold)
                            Text("المبلغ: ${req.amount} جنيه • ${req.months} شهر", fontSize = 13.sp)
                            Text("ملاحظة: ${req.note.ifBlank { "—" }}", fontSize = 12.sp, color = Color.Gray)
                            if (req.proofUrl.isNotBlank()) Text("إثبات التحويل: مرفوع", color = Color(0xFF0D7C3E), fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    enabled = busyId == null,
                                    onClick = {
                                        busyId = req.id
                                        scope.launch {
                                            try {
                                                repository.approveSubscription(req.id, req.driverId, req.months)
                                                pending = repository.listPendingSubscriptions()
                                            } catch (e: Exception) {
                                                error = e.localizedMessage
                                            } finally { busyId = null }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D7C3E))
                                ) { Text("قبول وتجديد") }
                                OutlinedButton(
                                    enabled = busyId == null,
                                    onClick = {
                                        busyId = req.id
                                        scope.launch {
                                            try {
                                                repository.rejectSubscription(req.id)
                                                pending = repository.listPendingSubscriptions()
                                            } catch (e: Exception) {
                                                error = e.localizedMessage
                                            } finally { busyId = null }
                                        }
                                    }
                                ) { Text("رفض") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminRidesTab() {
    val repository = remember { FirebaseRidesRepository() }
    var rides by remember { mutableStateOf<List<RideRecord>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        runCatching { rides = repository.listRecentRides(50) }
            .onFailure { error = it.localizedMessage }
    }

    Column(Modifier.fillMaxSize()) {
        Text("آخر الرحلات", fontWeight = FontWeight.Bold)
        if (error != null) Text(error!!, color = Color(0xFFB3261E))
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(rides, key = { it.id }) { ride ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${ride.from} → ${ride.to}", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        Text(
                            "${ride.status.arabicRideStatus()} • %.1f كم • ${ride.selectedPrice?.let { "$it ج" } ?: "—"}"
                                .format(ride.distanceKm),
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminRatingsTab() {
    val repository = remember { FirebaseRidesRepository() }
    var ratings by remember { mutableStateOf<List<RatingRecord>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        runCatching { ratings = repository.listRecentRatings(40) }
            .onFailure { error = it.localizedMessage }
    }

    Column(Modifier.fillMaxSize()) {
        Text("آخر التقييمات", fontWeight = FontWeight.Bold)
        if (error != null) Text(error!!, color = Color(0xFFB3261E))
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(ratings, key = { it.id }) { r ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${"★".repeat(r.stars)}${"☆".repeat(5 - r.stars)}  ${r.stars}/5", fontWeight = FontWeight.Bold)
                        if (r.comment.isNotBlank()) Text(r.comment, fontSize = 12.sp)
                        Text("رحلة: ${r.rideId.take(8)}…", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}
