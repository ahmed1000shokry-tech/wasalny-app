package com.wasalny.sidisalem

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await

/**
 * Single source of truth for ride state and Firebase operations.
 * Search/matching is performed by the trusted Cloud Function; the client only observes state.
 */
data class Coordinate(val latitude: Double, val longitude: Double)

data class RideRecord(
    val id: String,
    val customerId: String,
    val from: String,
    val to: String,
    val fromLat: Double,
    val fromLon: Double,
    val toLat: Double,
    val toLon: Double,
    val distanceKm: Double,
    val status: String,
    val searchRadiusMeters: Int,
    val selectedDriverId: String? = null,
    val selectedPrice: Int? = null,
    val driverLat: Double? = null,
    val driverLon: Double? = null,
    val createdAt: Long? = null
)

data class RideOffer(
    val driverId: String,
    val driverName: String,
    val price: Int,
    val etaMinutes: Int,
    val status: String
)

data class DriverRideRequest(
    val rideId: String,
    val from: String,
    val to: String,
    val fromLat: Double,
    val fromLon: Double,
    val distanceKm: Double,
    val radiusMeters: Int,
    val status: String
)

data class DriverCandidate(
    val uid: String,
    val displayName: String,
    val approved: Boolean,
    val available: Boolean,
    val lat: Double,
    val lon: Double,
    val updatedAt: Long?
)

data class DriverApplication(
    val uid: String,
    val name: String,
    val phone: String,
    val licenseType: String,
    val vehicleType: String,
    val idCardImageUrl: String = "",
    val vehicleImageUrl: String = "",
    val profileImageUrl: String = "",
    val approved: Boolean = false,
    val createdAt: Long? = null,
    val updatedAt: Long? = null
)

data class DriverLiveLocation(val lat: Double, val lon: Double, val updatedAt: Long?)

data class SubscriptionRequest(
    val id: String,
    val driverId: String,
    val driverName: String,
    val amount: Int,
    val months: Int,
    val proofUrl: String,
    val note: String,
    val status: String,
    val createdAt: Long? = null
)

data class DriverSubscription(
    val active: Boolean,
    val expiresAt: Long?,
    val plan: String,
    val daysLeft: Int
)

data class RatingRecord(
    val id: String,
    val rideId: String,
    val raterId: String,
    val stars: Int,
    val comment: String
)

data class DriverStats(
    val totalRides: Int,
    val completedRides: Int,
    val avgRating: Double,
    val totalEarnings: Int,
    val ratingCount: Int
)

data class CustomerStats(
    val totalRides: Int,
    val completedRides: Int,
    val cancelledRides: Int,
    val cancelsToday: Int,
    val isBanned: Boolean,
    val banUntil: Long?
)

class FirebaseRidesRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val functions: FirebaseFunctions = FirebaseFunctions.getInstance()
) {
    private val rides get() = db.collection("rides")
    private val drivers get() = db.collection("drivers")

    suspend fun isAdmin(uid: String): Boolean {
        val admin = db.collection("admins").document(uid).get().await()
        return admin.exists() && admin.getString("role") == "admin" && admin.getBoolean("active") == true
    }

    fun listenPendingDrivers(onChange: (List<DriverCandidate>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration =
        drivers.whereEqualTo("approved", false).addSnapshotListener { snapshot, error ->
            if (error != null) return@addSnapshotListener onError(error)
            onChange(snapshot?.documents.orEmpty().mapNotNull { it.toDriverCandidate() })
        }

    suspend fun setDriverApproval(uid: String, approved: Boolean) {
        drivers.document(uid).update(
            mapOf("approved" to approved, "available" to false, "updatedAt" to FieldValue.serverTimestamp())
        ).await()
    }

    suspend fun signInAnonymously(): String {
        val auth = FirebaseAuth.getInstance()
        return auth.currentUser?.uid ?: auth.signInAnonymously().await().user?.uid
        ?: error("تعذر إنشاء جلسة Firebase")
    }

    suspend fun saveUserProfile(uid: String, role: String, name: String, phone: String) {
        db.collection("users").document(uid).set(
            mapOf("uid" to uid, "role" to role, "name" to name, "phone" to phone, "updatedAt" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        ).await()
    }

    suspend fun saveFcmToken(uid: String, token: String) {
        val ref = db.collection("users").document(uid)
        val existing = ref.get().await()
        if (!existing.exists()) {
            ref.set(
                mapOf(
                    "uid" to uid,
                    "role" to "customer",
                    "name" to "",
                    "phone" to (com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.phoneNumber ?: ""),
                    "fcmToken" to token,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            ref.update(
                mapOf("fcmToken" to token, "updatedAt" to FieldValue.serverTimestamp())
            ).await()
        }
    }

    suspend fun saveDriverApplication(
        uid: String, name: String, phone: String, licenseType: String, vehicleType: String,
        idCardImageUrl: String = "", vehicleImageUrl: String = ""
    ) {
        val ref = drivers.document(uid)
        val existing = ref.get().await()
        val payload = mutableMapOf<String, Any>(
            "uid" to uid, "displayName" to name, "phone" to phone,
            "licenseType" to licenseType, "vehicleType" to vehicleType,
            "idCardImageUrl" to idCardImageUrl, "vehicleImageUrl" to vehicleImageUrl,
            "approved" to (existing.getBoolean("approved") ?: false), "available" to false,
            "lat" to Config.LAT, "lon" to Config.LON,
            "geohash" to com.firebase.geofire.GeoFireUtils.getGeoHashForLocation(
                com.firebase.geofire.GeoLocation(Config.LAT, Config.LON)
            ),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!existing.exists()) payload["createdAt"] = FieldValue.serverTimestamp()
        ref.set(payload, SetOptions.merge()).await()
    }

    suspend fun getDriverApplication(uid: String): DriverApplication? =
        drivers.document(uid).get().await().takeIf { it.exists() }?.let { snapshot ->
            DriverApplication(
                uid = snapshot.id,
                name = snapshot.getString("displayName") ?: "",
                phone = snapshot.getString("phone") ?: "",
                licenseType = snapshot.getString("licenseType") ?: "غير محدد",
                vehicleType = snapshot.getString("vehicleType") ?: "غير محدد",
                idCardImageUrl = snapshot.getString("idCardImageUrl") ?: "",
                vehicleImageUrl = snapshot.getString("vehicleImageUrl") ?: "",
                profileImageUrl = snapshot.getString("profileImageUrl") ?: "",
                approved = snapshot.getBoolean("approved") == true,
                createdAt = snapshot.getTimestamp("createdAt")?.toDate()?.time,
                updatedAt = snapshot.getTimestamp("updatedAt")?.toDate()?.time
            )
        }

    suspend fun ensureDriverProfile(uid: String, name: String) {
        val ref = drivers.document(uid)
        if (!ref.get().await().exists()) {
            val hash = com.firebase.geofire.GeoFireUtils.getGeoHashForLocation(
                com.firebase.geofire.GeoLocation(Config.LAT, Config.LON)
            )
            ref.set(mapOf(
                "uid" to uid, "displayName" to name, "approved" to false, "available" to false,
                "lat" to Config.LAT, "lon" to Config.LON, "geohash" to hash,
                "updatedAt" to FieldValue.serverTimestamp(), "createdAt" to FieldValue.serverTimestamp()
            )).await()
        }
    }

    suspend fun setDriverAvailability(uid: String, available: Boolean) {
        val ref = drivers.document(uid)
        val snapshot = ref.get().await()
        check(snapshot.getBoolean("approved") == true) { "السائق غير معتمد" }
        if (available) {
            val sub = getDriverSubscription(uid)
            check(sub.active) {
                "اشتراكك غير نشط. جدد عبر فودافون كاش على ${Config.VODAFONE_CASH} ثم انتظر موافقة المشرف."
            }
        }
        ref.update("available", available, "updatedAt", FieldValue.serverTimestamp()).await()
    }

    suspend fun publishDriverLocation(uid: String, name: String, point: Coordinate): Boolean {
        val ref = drivers.document(uid)
        val snapshot = ref.get().await()
        if (!snapshot.exists()) ensureDriverProfile(uid, name)
        val current = ref.get().await()
        if (current.getBoolean("approved") != true || current.getBoolean("available") != true) return false
        ref.update(
            mapOf(
                "displayName" to name, "lat" to point.latitude, "lon" to point.longitude,
                "geohash" to com.firebase.geofire.GeoFireUtils.getGeoHashForLocation(
                    com.firebase.geofire.GeoLocation(point.latitude, point.longitude)
                ), "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return true
    }

    suspend fun markDriverOffline(uid: String) {
        if (drivers.document(uid).get().await().exists()) {
            drivers.document(uid).update("available", false, "updatedAt", FieldValue.serverTimestamp()).await()
        }
    }

    suspend fun createRide(
        customerId: String, customerName: String, customerPhone: String,
        fromAddress: String, toAddress: String, from: Coordinate, to: Coordinate,
        distanceKm: Double, femaleMode: Boolean, withLuggage: Boolean,
        bookingType: String = "now",
        scheduledAt: Long? = null
    ): String {
        require(distanceKm > 0.0 && distanceKm <= 50.0) { "مسافة الرحلة غير صالحة" }
        assertCustomerNotBanned(customerId)
        val rideRef = rides.document()
        val isScheduled = bookingType == "school" && scheduledAt != null && scheduledAt > System.currentTimeMillis()
        if (bookingType == "school") require(scheduledAt != null && scheduledAt > System.currentTimeMillis() + 5 * 60_000) { "موعد الحجز يجب أن يكون بعد 5 دقائق على الأقل" }
        rideRef.set(mapOf(
            "customerId" to customerId, "customerName" to customerName,
            "fromAddress" to fromAddress, "toAddress" to toAddress,
            "fromLat" to from.latitude, "fromLon" to from.longitude,
            "toLat" to to.latitude, "toLon" to to.longitude,
            "distanceKm" to distanceKm, "femaleMode" to femaleMode, "withLuggage" to withLuggage,
            "bookingType" to bookingType, "status" to if (isScheduled) "scheduled" else "searching",
            "searchRadiusMeters" to 500, "searchStage" to 0,
            "scheduledAt" to scheduledAt,
            "invitedDriverIds" to emptyList<String>(),
            "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()
        )).await()
        rideRef.collection("private").document("contact").set(mapOf("customerPhone" to customerPhone)).await()
        return rideRef.id
    }

    suspend fun runSearch(rideId: String) {
        functions.getHttpsCallable("startRideSearch").call(mapOf("rideId" to rideId)).await()
    }

    suspend fun submitOffer(rideId: String, uid: String, driverName: String, price: Int, etaMinutes: Int) {
        require(price in 1..100_000) { "اكتب سعراً صحيحاً" }
        require(etaMinutes in 1..240) { "اكتب وقت وصول من دقيقة إلى 240 دقيقة" }
        val rideRef = rides.document(rideId)
        val offerRef = rideRef.collection("offers").document(uid)
        db.runTransaction { transaction ->
            val ride = transaction.get(rideRef)
            check(ride.getString("status") == "searching") { "انتهى استقبال عروض الرحلة" }
            check(transaction.get(offerRef).exists().not()) { "أرسلت عرضاً لهذه الرحلة بالفعل" }
            transaction.set(offerRef, mapOf(
                "driverId" to uid, "driverName" to driverName, "price" to price,
                "etaMinutes" to etaMinutes, "status" to "pending", "createdAt" to FieldValue.serverTimestamp()
            ))
            null
        }.await()
    }

    suspend fun selectOffer(rideId: String, customerId: String, driverId: String) {
        val rideRef = rides.document(rideId)
        val offerRef = rideRef.collection("offers").document(driverId)
        val requestRef = drivers.document(driverId).collection("requests").document(rideId)
        db.runTransaction { transaction ->
            val ride = transaction.get(rideRef)
            val offer = transaction.get(offerRef)
            val request = transaction.get(requestRef)
            check(ride.getString("customerId") == customerId) { "هذه الرحلة ليست لحسابك" }
            check(ride.getString("status") in listOf("searching", "offered")) { "لم تعد الرحلة متاحة" }
            check(offer.exists() && offer.getString("status") == "pending") { "هذا العرض لم يعد متاحاً" }
            val price = offer.getLong("price")
            check(price != null && price >= 1) { "سعر العرض غير صالح" }
            // طلب السائق قد لا يكون موجوداً في حالات نادرة — لا نفشل الاختيار بسببه
            if (request.exists()) {
                val reqStatus = request.getString("status")
                check(reqStatus == "searching" || reqStatus == "pending") { "دعوة السائق لم تعد متاحة" }
            }
            transaction.update(
                rideRef,
                mapOf(
                    "status" to "accepted",
                    "selectedDriverId" to driverId,
                    "selectedOfferId" to driverId,
                    "selectedPrice" to price,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            transaction.update(offerRef, "status", "selected")
            if (request.exists()) transaction.update(requestRef, "status", "selected")
            null
        }.await()
        // إغلاق طلبات باقي السائقين عبر Cloud Function (Admin SDK) لتجاوز قيود القواعد
        runCatching {
            functions.getHttpsCallable("closeOtherDriverRequests")
                .call(mapOf("rideId" to rideId, "selectedDriverId" to driverId))
                .await()
        }
    }

    suspend fun updateRideStatus(rideId: String, actorId: String, newStatus: String) {
        val ref = rides.document(rideId)
        val selectedDriverId = db.runTransaction { transaction ->
            val ride = transaction.get(ref)
            val customerId = ride.getString("customerId")
            val driverId = ride.getString("selectedDriverId")
            check(actorId == customerId || actorId == driverId) { "غير مصرح" }
            val current = ride.getString("status") ?: ""
            val allowed = when (current) {
                "searching", "scheduled", "offered" -> newStatus == "cancelled"
                "accepted" -> newStatus == "driver_arriving" || newStatus == "cancelled"
                "driver_arriving" -> newStatus == "driver_arrived" || newStatus == "cancelled"
                "driver_arrived" -> newStatus == "in_progress" || newStatus == "cancelled"
                "in_progress" -> newStatus == "completed" || newStatus == "cancelled"
                else -> false
            }
            check(allowed) { "انتقال غير مسموح: $current → $newStatus" }
            if (actorId == customerId) check(newStatus == "cancelled") { "الراكب لا ينفذ هذه الحالة" }
            if (newStatus == "cancelled" && current == "in_progress") {
                check(actorId == driverId || actorId == customerId) { "غير مصرح" }
            }
            transaction.update(ref, "status", newStatus, "updatedAt", FieldValue.serverTimestamp())
            driverId
        }.await()
        if (newStatus == "completed" || newStatus == "cancelled") {
            if (selectedDriverId != null) {
                runCatching { markDriverOffline(selectedDriverId) }
            }
        }
    }

    suspend fun cancelRide(rideId: String, customerId: String) {
        // حظر بعد أكثر من 3 إلغاءات في نفس اليوم
        val banCheck = getCustomerStats(customerId)
        check(!banCheck.isBanned) { "حسابك محظور مؤقتاً بسبب كثرة الإلغاءات. حاول بعد 24 ساعة." }
        updateRideStatus(rideId, customerId, "cancelled")
        // تسجيل الإلغاء في cancels/{اليوم}
        val todayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            .format(java.util.Date())
        val userRef = db.collection("users").document(customerId)
        val cancelRef = userRef.collection("cancels").document(todayKey)
        db.runTransaction { tx ->
            val snap = tx.get(cancelRef)
            val count = (snap.getLong("count") ?: 0L) + 1
            tx.set(
                cancelRef,
                mapOf("count" to count, "updatedAt" to FieldValue.serverTimestamp()),
                SetOptions.merge()
            )
            // الحظر يُكتب فقط لو وثيقة المستخدم موجودة مسبقاً (لتجنب فشل قواعد create)
            if (count > 3) {
                val userSnap = tx.get(userRef)
                if (userSnap.exists()) {
                    val banUntil = System.currentTimeMillis() + 24 * 60 * 60 * 1000L
                    tx.update(
                        userRef,
                        mapOf(
                            "banUntil" to banUntil,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }
            null
        }.await()
    }

    suspend fun assertCustomerNotBanned(customerId: String) {
        val stats = getCustomerStats(customerId)
        check(!stats.isBanned) { "حسابك محظور لمدة 24 ساعة بسبب إلغاء أكثر من 3 رحلات اليوم." }
    }

    suspend fun submitRating(rideId: String, raterId: String, stars: Int, comment: String = "") {
        require(stars in 1..5) { "التقييم من 1 إلى 5 نجوم" }
        val rideRef = rides.document(rideId)
        val ratingRef = rideRef.collection("ratings").document(raterId)
        db.runTransaction { tx ->
            val ride = tx.get(rideRef)
            check(ride.getString("status") == "completed") { "يمكن التقييم بعد انتهاء الرحلة فقط" }
            val customerId = ride.getString("customerId")
            val driverId = ride.getString("selectedDriverId")
            check(raterId == customerId || raterId == driverId) { "غير مصرح بالتقييم" }
            check(!tx.get(ratingRef).exists()) { "تم إرسال تقييمك بالفعل" }
            tx.set(ratingRef, mapOf(
                "raterId" to raterId,
                "stars" to stars,
                "comment" to comment.trim().take(300),
                "createdAt" to FieldValue.serverTimestamp()
            ))
            null
        }.await()
    }

    suspend fun hasSubmittedRating(rideId: String, raterId: String): Boolean =
        rides.document(rideId).collection("ratings").document(raterId).get().await().exists()

    suspend fun listenCustomerRidesOnce(customerId: String): List<RideRecord> = rides.whereEqualTo("customerId", customerId)
        .orderBy("createdAt", Query.Direction.DESCENDING).limit(30).get().await().documents.mapNotNull { it.toRideRecord() }

    suspend fun getRide(rideId: String): RideRecord? = rides.document(rideId).get().await().takeIf { it.exists() }?.toRideRecord()

    suspend fun getAcceptedCustomerPhone(rideId: String, driverId: String): String {
        val ride = rides.document(rideId).get().await()
        check(ride.getString("status") in listOf("accepted", "driver_arriving", "driver_arrived", "in_progress") && ride.getString("selectedDriverId") == driverId) {
            "بيانات التواصل تظهر للسائق المختار فقط"
        }
        return rides.document(rideId).collection("private").document("contact").get().await().getString("customerPhone") ?: ""
    }

    fun listenCustomerRides(customerId: String, onChange: (List<RideRecord>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration =
        rides.whereEqualTo("customerId", customerId).orderBy("createdAt", Query.Direction.DESCENDING).limit(30)
            .addSnapshotListener { snapshot, error ->
                if (error != null) onError(error) else onChange(snapshot?.documents.orEmpty().mapNotNull { it.toRideRecord() })
            }

    fun listenDriverRequests(driverId: String, onChange: (List<DriverRideRequest>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration =
        drivers.document(driverId).collection("requests").addSnapshotListener { snapshot, error ->
            if (error != null) onError(error) else onChange(snapshot?.documents.orEmpty().mapNotNull { doc ->
                DriverRideRequest(
                    rideId = doc.id, from = doc.getString("fromAddress") ?: "", to = doc.getString("toAddress") ?: "",
                    fromLat = doc.getDouble("fromLat") ?: return@mapNotNull null,
                    fromLon = doc.getDouble("fromLon") ?: return@mapNotNull null,
                    distanceKm = doc.getDouble("distanceKm") ?: 0.0,
                    radiusMeters = (doc.getLong("radiusMeters") ?: 500L).toInt(),
                    status = doc.getString("status") ?: "closed"
                )
            })
        }

    fun listenRide(rideId: String, onChange: (RideRecord?) -> Unit, onError: (Exception) -> Unit): ListenerRegistration =
        rides.document(rideId).addSnapshotListener { snapshot, error ->
            if (error != null) onError(error) else onChange(snapshot?.takeIf { it.exists() }?.toRideRecord())
        }

    fun listenOffers(rideId: String, onChange: (List<RideOffer>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration =
        rides.document(rideId).collection("offers").addSnapshotListener { snapshot, error ->
            if (error != null) onError(error) else onChange(snapshot?.documents.orEmpty().mapNotNull { doc ->
                RideOffer(
                    driverId = doc.getString("driverId") ?: doc.id,
                    driverName = doc.getString("driverName") ?: "سائق",
                    price = (doc.getLong("price") ?: return@mapNotNull null).toInt(),
                    etaMinutes = (doc.getLong("etaMinutes") ?: 0L).toInt(),
                    status = doc.getString("status") ?: "pending"
                )
            })
        }

    fun listenDriverLocation(rideId: String, onChange: (DriverLiveLocation?) -> Unit, onError: (Exception) -> Unit): ListenerRegistration =
        rides.document(rideId).collection("private").document("driverLocation").addSnapshotListener { snapshot, error ->
            if (error != null) onError(error) else if (snapshot?.exists() == true) {
                onChange(DriverLiveLocation(
                    lat = snapshot.getDouble("lat") ?: return@addSnapshotListener,
                    lon = snapshot.getDouble("lon") ?: return@addSnapshotListener,
                    updatedAt = snapshot.getTimestamp("updatedAt")?.toDate()?.time
                ))
            }
        }

    suspend fun getDriverApproval(uid: String): Boolean? {
        val snapshot = drivers.document(uid).get().await()
        return if (snapshot.exists()) snapshot.getBoolean("approved") == true else null
    }

    suspend fun getDriverAvailability(uid: String): Boolean =
        drivers.document(uid).get().await().getBoolean("available") == true

    // ─── الاشتراكات والإحصائيات ولوحة المشرف ───

    suspend fun getDriverSubscription(uid: String): DriverSubscription {
        val snap = drivers.document(uid).get().await()
        val expiresAt = snap.getTimestamp("subscriptionExpiresAt")?.toDate()?.time
            ?: snap.getLong("subscriptionExpiresAt")
        val now = System.currentTimeMillis()
        val active = expiresAt != null && expiresAt > now
        val daysLeft = if (expiresAt != null && expiresAt > now) {
            ((expiresAt - now) / (24 * 60 * 60 * 1000L)).toInt()
        } else 0
        return DriverSubscription(
            active = active,
            expiresAt = expiresAt,
            plan = snap.getString("subscriptionPlan") ?: "none",
            daysLeft = daysLeft
        )
    }

    suspend fun submitSubscriptionRequest(
        driverId: String,
        driverName: String,
        amount: Int,
        months: Int,
        proofUrl: String,
        note: String
    ): String {
        val ref = db.collection("subscriptionRequests").document()
        ref.set(
            mapOf(
                "driverId" to driverId,
                "driverName" to driverName,
                "amount" to amount,
                "months" to months,
                "proofUrl" to proofUrl,
                "note" to note.trim().take(300),
                "status" to "pending",
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return ref.id
    }

    suspend fun listPendingSubscriptions(): List<SubscriptionRequest> {
        // بدون orderBy لتجنب الحاجة لفهرس مركّب عند أول تشغيل
        val docs = db.collection("subscriptionRequests")
            .whereEqualTo("status", "pending")
            .limit(40)
            .get().await().documents
        return docs.map { doc ->
            SubscriptionRequest(
                id = doc.id,
                driverId = doc.getString("driverId") ?: "",
                driverName = doc.getString("driverName") ?: "",
                amount = (doc.getLong("amount") ?: 0L).toInt(),
                months = (doc.getLong("months") ?: 1L).toInt(),
                proofUrl = doc.getString("proofUrl") ?: "",
                note = doc.getString("note") ?: "",
                status = doc.getString("status") ?: "pending",
                createdAt = doc.getTimestamp("createdAt")?.toDate()?.time
            )
        }.sortedByDescending { it.createdAt ?: 0L }
    }

    suspend fun approveSubscription(requestId: String, driverId: String, months: Int) {
        val current = getDriverSubscription(driverId)
        val base = maxOf(System.currentTimeMillis(), current.expiresAt ?: 0L)
        val expiresAt = base + months * 30L * 24 * 60 * 60 * 1000
        val isFirst = current.plan == "none" || current.expiresAt == null
        drivers.document(driverId).set(
            mapOf(
                "subscriptionExpiresAt" to expiresAt,
                "subscriptionPlan" to if (isFirst) "first" else "monthly",
                "available" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).await()
        db.collection("subscriptionRequests").document(requestId).update(
            mapOf("status" to "approved", "updatedAt" to FieldValue.serverTimestamp())
        ).await()
    }

    suspend fun rejectSubscription(requestId: String) {
        db.collection("subscriptionRequests").document(requestId).update(
            mapOf("status" to "rejected", "updatedAt" to FieldValue.serverTimestamp())
        ).await()
    }

    suspend fun requestDriverMoreData(uid: String, message: String) {
        drivers.document(uid).set(
            mapOf(
                "needsMoreData" to true,
                "adminMessage" to message,
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).await()
    }

    suspend fun listAllDrivers(): List<DriverApplication> {
        val docs = runCatching {
            drivers.orderBy("createdAt", Query.Direction.DESCENDING).limit(80).get().await().documents
        }.getOrElse {
            drivers.limit(80).get().await().documents
        }
        return docs.map { snap ->
            DriverApplication(
                uid = snap.id,
                name = snap.getString("displayName") ?: "",
                phone = snap.getString("phone") ?: "",
                licenseType = snap.getString("licenseType") ?: "",
                vehicleType = snap.getString("vehicleType") ?: "",
                idCardImageUrl = snap.getString("idCardImageUrl") ?: "",
                vehicleImageUrl = snap.getString("vehicleImageUrl") ?: "",
                profileImageUrl = snap.getString("profileImageUrl") ?: "",
                approved = snap.getBoolean("approved") == true,
                createdAt = snap.getTimestamp("createdAt")?.toDate()?.time,
                updatedAt = snap.getTimestamp("updatedAt")?.toDate()?.time
            )
        }
    }

    suspend fun listRecentRides(limit: Int = 40): List<RideRecord> =
        runCatching {
            rides.orderBy("createdAt", Query.Direction.DESCENDING).limit(limit.toLong())
                .get().await().documents.mapNotNull { it.toRideRecord() }
        }.getOrElse {
            rides.limit(limit.toLong()).get().await().documents.mapNotNull { it.toRideRecord() }
        }

    suspend fun listRecentRatings(limit: Int = 40): List<RatingRecord> {
        // نجمع من آخر الرحلات
        val recent = listRecentRides(30)
        val result = mutableListOf<RatingRecord>()
        for (ride in recent) {
            val ratings = rides.document(ride.id).collection("ratings").get().await()
            for (doc in ratings.documents) {
                result.add(
                    RatingRecord(
                        id = "${ride.id}_${doc.id}",
                        rideId = ride.id,
                        raterId = doc.getString("raterId") ?: doc.id,
                        stars = (doc.getLong("stars") ?: 0L).toInt(),
                        comment = doc.getString("comment") ?: ""
                    )
                )
                if (result.size >= limit) return result
            }
        }
        return result
    }

    suspend fun getDriverStats(driverId: String): DriverStats {
        val completed = runCatching {
            rides.whereEqualTo("selectedDriverId", driverId)
                .whereEqualTo("status", "completed").limit(100).get().await().documents
        }.getOrElse {
            // بدون فهرس مركّب: نفلتر محلياً
            rides.whereEqualTo("selectedDriverId", driverId).limit(100).get().await().documents
                .filter { it.getString("status") == "completed" }
        }
        val totalEarnings = completed.sumOf { (it.getLong("selectedPrice") ?: 0L).toInt() }
        var starsSum = 0
        var ratingCount = 0
        for (ride in completed.take(40)) {
            runCatching {
                val ratings = rides.document(ride.id).collection("ratings").get().await()
                for (r in ratings.documents) {
                    if (r.getString("raterId") != driverId) {
                        starsSum += (r.getLong("stars") ?: 0L).toInt()
                        ratingCount++
                    }
                }
            }
        }
        return DriverStats(
            totalRides = completed.size,
            completedRides = completed.size,
            avgRating = if (ratingCount > 0) starsSum.toDouble() / ratingCount else 0.0,
            totalEarnings = totalEarnings,
            ratingCount = ratingCount
        )
    }

    suspend fun getCustomerStats(customerId: String): CustomerStats {
        val all = rides.whereEqualTo("customerId", customerId).limit(100).get().await().documents
        val completed = all.count { it.getString("status") == "completed" }
        val cancelled = all.count { it.getString("status") == "cancelled" }
        val todayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val cancelsToday = db.collection("users").document(customerId)
            .collection("cancels").document(todayKey).get().await().getLong("count")?.toInt() ?: 0
        val userSnap = db.collection("users").document(customerId).get().await()
        val banUntil = userSnap.getLong("banUntil")
            ?: userSnap.getTimestamp("banUntil")?.toDate()?.time
        val bannedByField = banUntil != null && banUntil > System.currentTimeMillis()
        // أكثر من 3 إلغاءات اليوم = محظور حتى لو banUntil لم يُكتب
        val isBanned = bannedByField || cancelsToday > 3
        return CustomerStats(
            totalRides = all.size,
            completedRides = completed,
            cancelledRides = cancelled,
            cancelsToday = cancelsToday,
            isBanned = isBanned,
            banUntil = banUntil
        )
    }

    suspend fun getDriverAvgRating(driverId: String): Double {
        return getDriverStats(driverId).avgRating
    }

    private fun DocumentSnapshot.toDriverCandidate() = DriverCandidate(
        uid = id, displayName = getString("displayName") ?: "بدون اسم",
        approved = getBoolean("approved") ?: false, available = getBoolean("available") ?: false,
        lat = getDouble("lat") ?: 0.0, lon = getDouble("lon") ?: 0.0,
        updatedAt = getTimestamp("updatedAt")?.toDate()?.time
    )

    private fun DocumentSnapshot.toRideRecord(): RideRecord? {
        val customerId = getString("customerId") ?: return null
        return RideRecord(
            id = id, customerId = customerId,
            from = getString("fromAddress") ?: "", to = getString("toAddress") ?: "",
            fromLat = getDouble("fromLat") ?: 0.0, fromLon = getDouble("fromLon") ?: 0.0,
            toLat = getDouble("toLat") ?: 0.0, toLon = getDouble("toLon") ?: 0.0,
            distanceKm = getDouble("distanceKm") ?: 0.0,
            status = getString("status") ?: "searching",
            searchRadiusMeters = (getLong("searchRadiusMeters") ?: 500L).toInt(),
            selectedDriverId = getString("selectedDriverId"),
            selectedPrice = (getLong("selectedPrice"))?.toInt(),
            driverLat = getDouble("driverLat"), driverLon = getDouble("driverLon"),
            createdAt = getTimestamp("createdAt")?.toDate()?.time
        )
    }
}
