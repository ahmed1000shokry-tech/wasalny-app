# وصلني توكتوك — سيدي سالم · V5.2.2

منصة حجز توكتوك لسيدي سالم: Android + Firebase (Auth / Firestore / Functions / FCM).

---

## ما يشمله الإصدار الحالي

### للمستخدم
- تسجيل برقم هاتف (SMS) + شروط وأحكام إلزامية
- راكب: اطلب رحلة دلوقت · من/إلى · مسافة · أفضل 5 عروض
- سائق: تسجيل وانتظار اعتماد · عروض سعر · حالات الرحلة
- بحث يتوسع تلقائيًا: 500م → 1كم → 2كم → 5كم
- تتبع موقع السائق أثناء الرحلة · تقييم بعد الانتهاء
- حظر الراكب 24 ساعة بعد أكثر من 3 إلغاءات في اليوم

### للسائق — اشتراك
- أول شهر 100 ج · التجديد 200 ج شهريًا
- التحويل فودافون كاش: **01069631950**
- إرسال إثبات للمراجعة · حالة الاشتراك والأيام المتبقية

### للمشرف
- دخول سري: 7 ضغطات على شعار «وصلني» ثم الكود **`5122017@Aa`**
- مراجعة السائقين · قبول/رفض الاشتراكات · الرحلات · التقييمات
- **مهم:** بعد أول دخول أضف UID في Firestore:
  ```
  admins/{UID} → { "role": "admin", "active": true }
  ```

### الأمان والتقنية
- Firestore Rules مفصّلة حسب الدور والحالة
- مطابقة السائقين على السيرفر (Cloud Functions)
- إغلاق طلبات باقي السائقين عند قبول عرض
- لا keystore ولا أسرار داخل المستودع

---

## هيكل المشروع

| المسار | الوظيفة |
|--------|---------|
| `app/` | تطبيق Android (Kotlin + Compose) |
| `functions/` | Backend: بحث · إشعارات · جدولة · إغلاق طلبات |
| `firestore.rules` | قواعد الأمان |
| `firestore.indexes.json` | الفهارس |
| `.github/workflows/` | بناء APK وفحص المشروع |

---

## أوامر التشغيل

### 1) Android (Debug APK)
```bash
./gradlew assembleDebug
# الناتج: app/build/outputs/apk/debug/app-debug.apk
```

### 2) Cloud Functions
```bash
cd functions
npm ci
npm run build
cd ..
```

### 3) نشر Firebase (إلزامي بعد أي تعديل rules/functions)
```bash
firebase use wasalny-app-f5dbb
firebase deploy --only firestore:rules,firestore:indexes,functions
```

### 4) GitHub
- ارفع المشروع على الريبو
- Secret: `GOOGLE_SERVICES_JSON` = محتوى google-services.json بـ Base64
- Workflow يبني Debug APK تلقائيًا على الدفع لـ main

---

## قائمة ما قبل الإطلاق

- [ ] تفعيل Phone Authentication في Firebase
- [ ] أرقام اختبار SMS أثناء التطوير (احذفها قبل الإنتاج)
- [ ] `firebase deploy` للقواعد والدوال
- [ ] وثيقة مشرف في `admins`
- [ ] تجربة راكب + سائق على جهازين
- [ ] التأكد من فودافون كاش 01069631950
- [ ] بناء Release عند الجاهزية للتوزيع العام

---

## الإصدار
- **versionName:** 5.2.2  
- **versionCode:** 9  
- **applicationId:** `com.wasalny.sidisalem`  
- **Firebase project:** `wasalny-app-f5dbb`

الدفع إلكتروني غير مفعّل — الأجرة نقدية حسب الاتفاق بين الراكب والسائق.
